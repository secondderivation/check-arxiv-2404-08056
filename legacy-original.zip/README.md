# Check of arXiv:2404.08056v3

**Interpreting DESI's evidence for evolving dark energy** — M. Cortês, A. R. Liddle. JCAP 12 (2024) 007. [arXiv:2404.08056v3](https://arxiv.org/abs/2404.08056v3).

**Result: Reproduced, with notes (checked scope).** This paper is a short interpretation note on DESI's 2024 evidence for evolving dark energy. It argues that the evidence sits in the slope of w(a), not its level at the best-measured epoch, and that it depends strongly on the prior. It has no fit of its own, so we checked its statements on DESI's own public DR1 posterior chains. The pivot transformation the authors could only estimate by eye was done exactly. The main reading holds: at the pivot, w is within a few hundredths of −1 for all three supernova samples, and all three 95 % contours reach w = −1. The stated precision of ± 0.02 does not hold for DESY5, where w_p = −0.945 ± 0.026 lies 2.1σ from −1. On priors, DESI's evidence does depend on the prior, but the direction is not fixed. Strong penalties on phantom histories lower both the Bayes factor and the credible level. Priors centred on ΛCDM lower the credible level but raise the Bayes factor. We list four points that narrow the paper's wording and three presentation slips as notes. This is a scoped reproduction, not a certification of the entire paper.

> **Draft, not released.** Local release candidate; the fresh-conversation verification (P2) and owner approval (P3) are pending.

## What we checked

- The DESI significances, priors and pivot redshifts the paper quotes, against DESI 2024 VI v1, v2 and v3 (C1–C3, C10)
- The pivot values of w(a) behind Fig. 2 and the ± 0.02 / 'a few hundredths' statements, from DESI's chains (C4)
- The algebra of the pivot transformation, and the claim that the induced prior on w_p is flat (C5)
- The orientation of the w0–w_a contours, their offset from w_p = −1, and the pivot-shifted contours the paper could not draw (C6)
- The four zones of Fig. 1, where the posterior lies among them, and the drawn lines (C7)
- The phantom crossing, the maximum of the dark-energy density, and its position against the pivot (C8)
- The prior argument: what DESI's significances and Bayes factors depend on, and what five prior variants fixed before the run do to the Bayes factor and to the credible level of ΛCDM (C9)

**Not checked:**

- A new fit or optimisation. All numbers come from reweighting DESI's released chains, so DESI's own maximum-posterior statistic was not recomputed under a changed prior
- New nested-sampling evidences. Absolute Bayes factors are DESI's printed ln B (0.65, 2.4, 2.8) plus the change computed here. If DESI normalised its prior over the full box rather than the w0 + w_a < 0 wedge, every absolute value would move by 0.255 in magnitude; the changes would not
- The never-phantom prior (T5) beyond a rough estimate: only 2 to 31 effective samples survive it, so it needs its own sampler
- How wide the observational window behind the pivot is, and how likely an alignment of the contours with w_p = −1 would be under ΛCDM
- Whether the CPL family describes the dark energy beyond the observed range; the 'maximum it will ever have' statement holds only for CPL extrapolated to all times

## Claims (10 checked, 3 reproduced within tolerance)

| Claim | Where | Result | Output |
|---|---|---|---|
| C1 | l.55, l.128 | Reproduced | [`checks/out/quoted.out`](checks/out/quoted.out) |
| C2 | l.68 and footnote | Reproduced | [`checks/out/chain_checks_dr1.out`](checks/out/chain_checks_dr1.out) |
| C3 | Fig. 1 caption (l.89), l.96, Fig. 2 caption (l.105) | Reproduced | [`checks/out/chain_checks_dr1.out`](checks/out/chain_checks_dr1.out) |
| C4 | l.100, l.105-108 (Fig. 2 and its recipe comment), l.115 | Reproduced; the plotted points are posterior means, not best fits, and '± 0.02' holds only for PantheonPlus: N1, N2 | [`checks/out/chain_checks_dr1.out`](checks/out/chain_checks_dr1.out) |
| C5 | l.72-76, l.119 | Algebra reproduced; the marginal prior on w_p is not flat (N3) | [`checks/out/prior_volume.out`](checks/out/prior_volume.out) |
| C6 | l.96, l.119, Fig. 1 | Partly reproduced: the contours align with w_p = −1, but DESY5 is offset by 2.15σ (N2) | [`checks/out/contours_dr1.out`](checks/out/contours_dr1.out) |
| C7 | l.94, Fig. 1 lines and labels | Reproduced; one line in Fig. 1 is misdrawn (N4) | [`checks/out/contours_dr1.out`](checks/out/contours_dr1.out) |
| C8 | l.100, l.115, l.117, l.136 | Partly reproduced: the maximum-density result holds, but for DESY5 the crossing lies above the pivot (N5) | [`checks/out/chain_checks_dr1.out`](checks/out/chain_checks_dr1.out) |
| C9 | abstract, l.128-132, l.136-138 | Partly reproduced: the dependence on the prior is real and was stated by DESI; its direction depends on the prior: N6, N7 | [`checks/out/priors_dr1.out`](checks/out/priors_dr1.out) |
| C10 | l.84, l.123, l.134 | Reproduced; one wording difference ('significantly' for DESI's 'mildly') (N6) | [`checks/out/quoted.out`](checks/out/quoted.out) |

The original scientific plan and its dated amendments are preserved in `PROTOCOL.md`. It includes expectations later corrected. Release replay gates are separate, post-hoc engineering checks in `VALIDATION.md`; they do not erase scientific exceptions. Printed inputs are in `paper_values.json`.

## Notes

- **N1** (S0, l.100, Fig. 2 caption). The plotted (w0, w_a) values are called best fits. DESI VI gives them as marginal posterior means, already in its first version, and its DESY5 maximum-posterior point is (−0.733, −1.010) against the plotted (−0.727, −1.05). Nothing in the paper depends on the difference. [`checks/out/desi_versions.out`](checks/out/desi_versions.out)
- **N2** (S1, abstract, l.96–100). 'To a precision around ± 0.02' and the abstract's 'matches … precisely' hold for PantheonPlus only. From DESI's chains, |E[w_p] + 1| is 0.018, 0.040 and 0.055 for PantheonPlus, Union3 and DESY5. In units of σ(w_p) at DESI's pivots that is 0.66, 0.97 and 2.15 (contours_dr1.out has the pivot-shifted contours). For DESY5, the sample DESI calls its strongest evidence, w_p = −0.945 ± 0.026 and the line w_p = −1 misses the 68 % region. 'A few hundredths' holds for all three, and all three 95 % contours reach w_p = −1. In a Gaussian split, the level of w accounts for 5 %, 9 % and 26 % of the distance from ΛCDM, so the evidence does sit mostly in the slope. [`checks/out/chain_checks_dr1.out`](checks/out/chain_checks_dr1.out)
- **N3** (S1, l.74–76, l.121). The pivot shear has Jacobian 1, so the joint prior in (w_p, w_a) stays flat, but the marginal prior on w_p does not: because of DESI's condition w0 + w_a < 0 it varies by 11.8–12.3 % over w_p in [−1.2, −0.8]. Inside the posterior the tilt shifts E[w_p] by about 2 × 10⁻⁴, so no number changes. Likewise the shift removes the linear correlation but adds no information ('remove the degeneracy', l.121): σ(w_a) and the area of the contours are unchanged. [`checks/out/prior_volume.out`](checks/out/prior_volume.out)
- **N4** (S0, Fig. 1). The magenta line w0 + w_a = −1 is drawn with slope about −0.89 instead of −1 and is off by up to 0.068 in w0; the other three lines are within 0.013. No posterior mass that matters lies near it: 0.3 % or less of each posterior is outside the early-phantom zone. [`checks/out/fig1_lines.out`](checks/out/fig1_lines.out)
- **N5** (S0, l.100, l.115–117, abstract). The density of dark energy peaks where w crosses −1, which the chains place at median z = 0.30, 0.39 and 0.35. For PantheonPlus and Union3 DESI's pivot lies inside the 68 % range of the crossing; for DESY5 (0.26 against 0.31–0.42) it does not. This is N2 seen in redshift. The maximum is the largest density the dark energy will ever have only if CPL holds for all future times. [`checks/out/chain_checks_dr1.out`](checks/out/chain_checks_dr1.out)
- **N6** (S1, l.128, l.134). The paper calls DESI's prior dependence 'unstated'. DESI VI states that its Bayesian evidence depends on the prior ranges, already in its first version ('mildly'). Its quoted 2.5, 3.5 and 3.9σ compare maximum-posterior points, and with DESI's flat prior they do not depend on the prior's shape; a prior that is not flat could move them, which we did not recompute. Separately, the paper calls DESI's z = 0.51 point 'significantly' displaced where DESI says 'mildly' (about 2σ). [`checks/out/desi_versions.out`](checks/out/desi_versions.out)
- **N7** (S1, l.130–132, abstract). The paper says down-weighting models far from theoretical expectations would reduce or remove the evidence. We reweighted DESI's chains with five prior variants fixed before the run. The credible level of ΛCDM falls under the four smooth ones, by 0.07–0.48σ. The Bayes factor falls for all three samples only under a strong penalty on phantom values (T2). It rises, by up to +1.9 in ln B, under Gaussian priors centred on ΛCDM (T3, T4), because those remove prior volume where the likelihood is negligible. A further variant built after the first results, penalising the depth and duration of a phantom phase (v6_t6.out), lowers both measures for all three samples, and takes ln B just below zero for PantheonPlus and Union3 at width 0.10. So the weakening the paper describes happens for strong enough penalties on phantom histories, but it is not guaranteed by moving prior weight towards theory. The abstract's claim that the evidence is strongly prior-dependent holds. [`checks/out/priors_dr1.out`](checks/out/priors_dr1.out)

**Context.** Two other AI models checked this paper: one re-did every claim blind with its own code, and all 130 numbers both computed agree within tolerance; a critic then tried to drop or soften each note, re-derived the reweighting and proposed the phantom-duration prior in N7. Their reports are not part of this package. Later work has used theory-informed priors on DESI's posteriors (Toomey et al., arXiv:2509.13318, reweighting their own DR2 chains, report the CMB + DESI tension falling from about 3.1σ to 1.3σ), and the authors' own follow-up (arXiv:2504.15336) revisits the pivot with DESI DR2.

## Newer data

- **M1** (DESI DR2 public chains). With DESI's 2025 (DR2) chains, each at its own pivot, w_p is 0.63, 0.87 and 1.91σ from −1 for PantheonPlus, Union3 and DESY5, and all three 95 % contours reach w_p = −1 (contours_dr2.out). The prior response keeps its mixed sign (priors_dr2.out). DESI DR2 itself calls the alignment of the contours with ΛCDM 'a weak coincidence'. [`checks/out/chain_checks_dr2.out`](checks/out/chain_checks_dr2.out)

A re-test on newer data describes how the model fares; it does not change whether the paper's own work reproduces.

## Datasets

| Dataset | Release | Role | Used for | Links |
|---|---|---|---|---|
| DESI 2024 (DR1) cosmological constraints | DR1 (2024) | published value, taken as printed | C1, C2, C3, C4, C5, C9, C10 | [source](https://arxiv.org/abs/2404.03002) · [DESI 2024 VI](https://arxiv.org/abs/2404.03002) |
| DESI DR1 (DESI 2024 VI) public Cobaya MCMC chains: flat w0waCDM, wCDM and LCDM runs used in 2404.08056 | DR1 value-added catalogue bao-cosmo-params v1.0 | data the paper used | C0.1, C0.2, C2, C3, C4, C5, C6, C7, C8, C9 | [source](https://data.desi.lbl.gov/doc/releases/dr1/) · [DESI 2024 VI](https://arxiv.org/abs/2404.03002) · [DESI DR1 data release paper](https://arxiv.org/abs/2503.14745) · 56 pinned files (datasets.json) |
| DESI DR2 Results II public Cobaya MCMC chains: flat w0waCDM, wCDM and LCDM runs (re-test M1 of 2404.08056) | DR2 papers/y3 bao-cosmo-params (v1.0 per DESI's checksum list) | newer release of the paper's data | M1 | [source](https://data.desi.lbl.gov/public/papers/y3/bao-cosmo-params/) · [DESI DR2 Results II](https://arxiv.org/abs/2503.14738) · 90 pinned files (datasets.json) |
| DESI DR2 (2025) cosmological constraints | DR2 (2025) | published value, taken as printed | M1 | [source](https://arxiv.org/abs/2503.14738) · [DESI DR2 Results II](https://arxiv.org/abs/2503.14738) |

**DESI DR1 (DESI 2024 VI) public Cobaya MCMC chains: flat w0waCDM, wCDM and LCDM runs used in 2404.08056; DESI DR2 Results II public Cobaya MCMC chains: flat w0waCDM, wCDM and LCDM runs (re-test M1 of 2404.08056).** This research used data obtained with the Dark Energy Spectroscopic Instrument (DESI). DESI construction and operations is managed by the Lawrence Berkeley National Laboratory. This material is based upon work supported by the U.S. Department of Energy, Office of Science, Office of High-Energy Physics, under Contract No. DE-AC02-05CH11231, and by the National Energy Research Scientific Computing Center, a DOE Office of Science User Facility under the same contract. (Full DESI acknowledgement text: https://data.desi.lbl.gov/doc/acknowledgments/)

Data files are not copied here. `python3 fetch_data.py` downloads them from the pinned links above and checks their SHA-256.

## How it was done

The checks were written and run with AI models in subscription sessions, overseen by one researcher who reviews each step and approves each release. Model agreement is not treated as confirmation.

| Model | Role | Tokens in / out | Model time |
|---|---|---|---|
| `claude-opus-5-5` (high), Claude Code 2.1.302 | first check, corrections and responses | 60.6M / 206k | 71 min |
| `gpt-6-astra` (high), Codex Desktop 0.163.0-alpha.10.2 | independent re-check with its own code; critic: tried to drop or soften each note | 7.8M / 54k | 27 min |

Total: 332k uncached input tokens (excluding cache writes), 1.7M cache-write tokens and 66.3M cache-read tokens, 260k output tokens, 98 minutes of model time. Read from each session's own log (Codex rollout files; Claude Code session records). Sessions ran on subscriptions, so no per-token price applies. Model time is the time the model was working, tool runs included. Each check ran in its own conversation. Per-stage figures are in `effort.json`. Work that was not recorded from a log, such as building this package, is not in the totals.

## Run it

```sh
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m unittest test_validation.py   # the comparison rejects known failure modes
python3 reproduce.py --all    # full suite; required for release verification
```

Runtime: a download of about 1.25 GB of pinned DESI chains (DR1 and DR2), then about 25 seconds without --all; with --all, about 3 minutes more, mostly the T6 prior reweighting (measured on 4 cores).

Every published file is checked against `MANIFEST.txt` (SHA-256) before and after the run. The run works in a copy under `_runs/`, so the saved outputs are never overwritten. Without `--all` the slow sampler checks are skipped. A passing replay does not change any claim result above.

## Cite

Cite the original paper first. To cite this check, use `CITATION.cff`. Code: BSD-3-Clause. Text: CC BY 4.0.
